#!/usr/bin/env python3

from timecard.__main__ import main

main()
